#ifndef __SUB_H__
#define __SUB_H__


make_helper(sub_i2rm_v);
make_helper(sub_si2rm_v);
make_helper(sub_r2rm_v);
make_helper(sub_rm2r_v);

#endif
