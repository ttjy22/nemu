#ifndef __SBB_H__
#define __SBB_H__


make_helper(sbb_r2rm_v);

#endif
